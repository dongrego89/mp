#ifndef ENTRADASALIDA_H
#define ENTRADASALIDA_H

void rellenaVector(int * v, int n);
void imprimeVector(int * v, int n);
void rellenaMatriz(int ** m, int fil, int col);
void imprimeMatriz(int ** m, int fil, int col);

#endif
