var searchData=
[
  ['extraemayores',['extraeMayores',['../ejercicio_8c.html#af2da671b1f046753a92b2fb213f0f5a5',1,'ejercicio.c']]]
];
