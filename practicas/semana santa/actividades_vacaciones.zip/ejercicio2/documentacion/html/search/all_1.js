var searchData=
[
  ['ejercicio_2dmain_2ec',['ejercicio-main.c',['../ejercicio-main_8c.html',1,'']]],
  ['ejercicio_2ec',['ejercicio.c',['../ejercicio_8c.html',1,'']]],
  ['extraemayores',['extraeMayores',['../ejercicio_8c.html#af2da671b1f046753a92b2fb213f0f5a5',1,'ejercicio.c']]]
];
