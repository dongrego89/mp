var searchData=
[
  ['main',['main',['../ejercicio-main_8c.html#a51af30a60f9f02777c6396b8247e356f',1,'ejercicio-main.c']]]
];
