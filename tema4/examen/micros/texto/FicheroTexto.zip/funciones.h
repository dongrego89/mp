#ifndef FUNCIONES_H
#define FUNCIONES_H

#define MAX_CHAR 300

int compruebaFichero(char * nombre);
void actualizaEdad(char * nombre);
void distribuyePorSexo(char * nombre, char * chicos, char * chicas);
void mezclaAlumnos(char * nombre, char * chicos, char * chicas);

#endif
